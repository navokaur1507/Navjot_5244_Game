//
//  GameScene.swift
//  TwoPlayer
//
//  Created by Anna Nekha Shabu on 2019-02-14.
//  Copyright © 2019 Anna Nekha Shabu. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene, SKPhysicsContactDelegate{
    
    private var label : SKLabelNode?
    private var spinnyNode : SKShapeNode?
    
    var turn = "player1"
    var bomb: SKSpriteNode?
    var player_1: SKSpriteNode?
    var player_2: SKSpriteNode?
    var life_1: SKLabelNode?
    var life_2: SKLabelNode?
    var message: SKLabelNode?
    var score_1 = 0
    var score_2 = 0
    

    
    // For Collision
    let player_A_Category: UInt32 = 0x1 << 1
    let player_B_Category: UInt32 = 0x1 << 2
    let bombCategory: UInt32 = 0x1 << 3
    
    
    override func didMove(to view: SKView) {
      
    
        physicsWorld.contactDelegate = self
        
        life_1 = childNode(withName: "player1") as? SKLabelNode
        life_2 = childNode(withName: "player2") as? SKLabelNode
        message = childNode(withName: "message") as? SKLabelNode
        player_1 = childNode(withName: "player1") as? SKSpriteNode
        player_2 = childNode(withName: "player2") as? SKSpriteNode
        //bomb = childNode(withName: "bomb") as? SKSpriteNode
    
        //collision and contact logic.
        
        bomb?.physicsBody?.categoryBitMask = bombCategory
        bomb?.physicsBody?.contactTestBitMask = player_A_Category
        bomb?.physicsBody?.collisionBitMask = player_B_Category
    

    
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    
    {
        var pos : CGPoint
        if(turn == "player1")
        {
            pos = (player_1?.position)!
            bomb?.removeFromParent()
            print("player 1-----\(pos)")
           createBomb(x: pos.x, y: pos.y)
            turn = "player2"
            message?.text = turn + "turn"
        }
        
        else if(turn == "player2")
        {
            pos = (player_2?.position)!
            bomb?.removeFromParent()
            print("player 2-----\(pos)")
           createBomb(x: pos.x, y: pos.y)
            turn = "player1"
            message?.text = turn + "turn"
        }
    }
    
    func createBomb(x: CGFloat, y: CGFloat)
    
    {   bomb = SKSpriteNode(imageNamed: "bomb")
        bomb!.position = CGPoint(x: x, y: y)
        addChild(bomb!)
        
    }
    
    
    func didBegin(_ contact: SKPhysicsContact) {
        
        print("Contact!!!")
        
        if contact.bodyB.categoryBitMask == player_A_Category
        {
            bomb?.removeFromParent()
            print("Removed!!!")
        }
        
        if contact.bodyA.categoryBitMask == player_B_Category
        {
            bomb?.removeFromParent()
            print("Removed!!!")
        }
        
        }
        
    }
    
